from functools import reduce
from itertools import groupby
from yaml import dump, Dumper, load, Loader

import difflib
import re

DEFAULT_SECTIONS = [
    "Preparation",
    "Tech Writing",
    "Record/Edit/Upload",
    "Peer Review",
    "Publication",
]

SECTIONS_WITH_VIDEO_EDITING = [
    "Preparation",
    "Tech Writing",
    "Record",
    "Edit/Upload",
    "Peer Review",
    "Publication",
]


class InvalidSyllabusError(Exception):
    pass


class Task:
    def __init__(
        self,
        name,
        *,
        tags=[],
        dependencies=[],
        subtasks=[],
        is_milestone=False,
        assigned_team=None,
    ):
        self.name = name
        self.tags = tags
        self.dependencies = dependencies
        self.subtasks = subtasks
        self.is_milestone = is_milestone
        self.assigned_team = assigned_team


def parse_syllabus_file(yaml_file_name):
    """
    Returns the syllabus dictionary from the YAML file.
    The main difference between this and parsing the file manually is that the `lesson` type will be explicitly added.
    """
    with open(yaml_file_name) as f:
        syllabus = load(f, Loader=Loader)

    try:
        for section in syllabus["sections"]:
            for index, item in enumerate(section["items"]):
                if type(item) == str:
                    section["items"][index] = {"name": item.strip(), "type": "lesson"}
                else:
                    section["items"][index]["name"] = item["name"].strip()
    except KeyError:
        raise InvalidSyllabusError("syllabus couldn't be parsed")

    return syllabus


def write_syllabus_file(syllabus, file_name):
    """
    Write the syllabus dictionary to disk as a YAML file.
    """
    with open(file_name, "w") as f:
        dump(syllabus, f, Dumper=Dumper)


def separate_change_syllabus(syllabus):
    """
    Returns 3 separate syllabus dictionaries. One for changes, insertions, and deletions.
    """
    changes = {"sections": []}
    insertions = {"sections": []}
    deletions = {"sections": []}

    for section in syllabus["sections"]:
        section_name = section["name"]

        change_items = list(filter(lambda i: i.get("change_to"), section["items"]))
        insert_items = list(
            filter(
                lambda i: not i.get("change_to") and not i.get("delete"),
                section["items"],
            )
        )
        delete_items = list(filter(lambda i: i.get("delete"), section["items"]))

        if change_items:
            changes["sections"].append(
                {"name": section_name, "items": change_items,}
            )

        if insert_items:
            insertions["sections"].append({"name": section_name, "items": insert_items})

        if delete_items:
            deletions["sections"].append({"name": section_name, "items": delete_items})

    return (changes, insertions, deletions)


def prioritized_sections_for_deletion(sectioned_tasks):
    """
    Returns the list of section names sorted with the sections containing tasks that have 'assigned_teams' first.
    """
    return sorted(
        sectioned_tasks,
        key=lambda n: any(
            [t.get("assigned_team") for t in sectioned_tasks[n]["tasks"]]
        ),
        reverse=True,
    )


def merge_old_and_new_tasks(old_section_tasks, new_section_tasks):
    """
    Takes the 'id' and 'name' values from the tasks in `old_section_tasks` and adds them to the corresponding task
    in `new_section_tasks` as 'id' and 'old_name'.

    Will raise an error if the number of tasks doesn't match between both sets of tasks.
    """
    for section_name, old_section in old_section_tasks.items():
        for index, task in enumerate(old_section["tasks"]):
            new_section_tasks[section_name]["tasks"][index].update(
                {"id": task["id"], "old_name": task["name"],}
            )


def required_section_names(with_video_editing):
    return SECTIONS_WITH_VIDEO_EDITING if with_video_editing else DEFAULT_SECTIONS


def generate_section_tasks(syllabus, with_video_editing=False):
    if not with_video_editing:
        sections = reduce(
            lambda acc, item: __add_section(acc, item), DEFAULT_SECTIONS, {}
        )
    else:
        sections = reduce(
            lambda acc, item: __add_section(acc, item), SECTIONS_WITH_VIDEO_EDITING, {}
        )

    previous_section_name = None
    for section in syllabus["sections"]:
        section_name = section.get("name")
        if previous_section_name:
            tasks = build_section_completion_tasks(
                previous_section_name, with_video_editing
            )
            __add_tasks_to_sections(sections, tasks)

        previous_section_name = section_name

        for item in section["items"]:
            if type(item) == str:
                item = {"type": "lesson", "name": item}

            if item["type"].lower() == "lesson":
                tasks = build_video_tasks(
                    previous_section_name, item, with_video_editing
                )
                __add_tasks_to_sections(sections, tasks)
            elif item["type"].lower() == "lab":
                tasks = build_lab_tasks(item, with_video_editing)
                __add_tasks_to_sections(sections, tasks)
            elif item["type"].lower() == "exam":
                tasks = build_exam_tasks(item, with_video_editing)
                __add_tasks_to_sections(sections, tasks)
            else:
                print(f"Unknown item type: {item['type']} for {item['name']}")

    __add_final_tasks(sections, previous_section_name, with_video_editing)

    return sections


def insertable_tasks_for_syllabus_item(
    item,
    syllabus_section,
    with_video_editing=False,
    insert_before=None,
    insert_after=None,
):
    tasks = __build_target_tasks(syllabus_section, item, with_video_editing)

    if not tasks:
        return {}

    if not insert_before and not insert_after:
        # Add just before section ending
        target_tasks = build_section_completion_tasks(
            syllabus_section, with_video_editing
        )
        for section_name, section in tasks.items():
            targets = target_tasks[section_name]["tasks"]

            # There are no section complete tasks in Peer Review
            if len(targets) == 0 and section_name == "Peer Review":
                for task in section["tasks"]:
                    task["insert_before"] = {
                        "section": section_name,
                        "name": "Peer Review Complete",
                    }
            elif len(targets) == 0:
                continue
            else:
                for task in section["tasks"]:
                    task["insert_before"] = {
                        "section": section_name,
                        "name": targets[0]["name"],
                    }

    elif insert_before:
        target_tasks = __build_target_tasks(
            syllabus_section, insert_before, with_video_editing
        )

        for section_name, section in tasks.items():
            targets = target_tasks[section_name]["tasks"]

            if len(targets) == 0:
                continue

            for task in section["tasks"]:
                task["insert_before"] = {
                    "section": section_name,
                    "name": targets[0]["name"],
                }
    else:
        target_tasks = __build_target_tasks(
            syllabus_section, insert_after, with_video_editing
        )

        for section_name, section in tasks.items():
            targets = target_tasks[section_name]["tasks"]

            if len(targets) == 0:
                continue

            for task in section["tasks"]:
                task["insert_after"] = {
                    "section": section_name,
                    "name": targets[0]["name"],
                }

    return tasks


def __build_target_tasks(syllabus_section, item, with_video_editing=False):
    if item["type"].lower() == "lesson":
        tasks = build_video_tasks(syllabus_section, item, with_video_editing)
    elif item["type"].lower() == "exam":
        tasks = build_exam_tasks(item, with_video_editing)
    elif item["type"].lower() == "lab":
        tasks = build_lab_tasks(item, with_video_editing)
    else:
        print(f"Unknown item type: {item['type']}")
        return {}

    return tasks


def build_video_tasks(section_name, item, with_video_editing=False):
    lesson_task_name = f"{item['name']} ({section_name})"

    tasks = __tasks_dictionary(with_video_editing)

    tasks["Preparation"]["tasks"].append({"name": lesson_task_name, "tags": ["lesson"]})

    tasks["Tech Writing"]["tasks"].append(
        {
            "name": lesson_task_name,
            "tags": ["lesson"],
            "dependencies": [{"section": "Preparation", "name": lesson_task_name}],
            "assigned_team": "TW",
        }
    )

    if not with_video_editing:
        tasks["Record/Edit/Upload"]["tasks"].append(
            {
                "name": lesson_task_name,
                "tags": ["lesson"],
                "dependencies": [{"section": "Tech Writing", "name": lesson_task_name}],
            }
        )

        tasks["Peer Review"]["tasks"].append(
            {
                "name": lesson_task_name,
                "tags": ["lesson"],
                "dependencies": [
                    {"section": "Record/Edit/Upload", "name": lesson_task_name}
                ],
            }
        )
    else:
        tasks["Record"]["tasks"].append(
            {
                "name": lesson_task_name,
                "tags": ["lesson"],
                "dependencies": [{"section": "Tech Writing", "name": lesson_task_name}],
            }
        )

        tasks["Edit/Upload"]["tasks"].append(
            {
                "name": lesson_task_name,
                "tags": ["lesson"],
                "dependencies": [{"section": "Record", "name": lesson_task_name}],
            }
        )

        tasks["Peer Review"]["tasks"].append(
            {
                "name": lesson_task_name,
                "tags": ["lesson"],
                "dependencies": [{"section": "Edit/Upload", "name": lesson_task_name}],
            }
        )

    return tasks


def build_lab_tasks(item, with_video_editing=False):
    task_name = f"Lab - {item['name']}"

    tasks = __tasks_dictionary(with_video_editing)

    tasks["Preparation"]["tasks"].append(
        {"name": task_name, "tags": ["lab"],}
    )

    tasks["Publication"]["tasks"].append(
        {
            "name": f"Publish Lab: {item['name']}",
            "tags": ["lab"],
            "dependencies": [
                {"section": "Tech Writing", "name": f"Lab Guide: {item['name']}"}
            ],
        }
    )

    if not with_video_editing:
        tasks["Record/Edit/Upload"]["tasks"].append(
            {
                "name": task_name,
                "tags": ["lab"],
                "dependencies": [{"section": "Preparation", "name": task_name}],
            }
        )
        tasks["Tech Writing"]["tasks"].append(
            {
                "name": f"Lab Guide: {item['name']}",
                "tags": ["lab"],
                "dependencies": [{"section": "Record/Edit/Upload", "name": task_name}],
                "assigned_team": "TW",
            }
        )
        tasks["Tech Writing"]["tasks"].append(
            {
                "name": f"Lab Diagram: {item['name']}",
                "tags": ["lab"],
                "dependencies": [{"section": "Preparation", "name": task_name}],
                "assigned_team": "TW",
            }
        )
        tasks["Peer Review"]["tasks"].append(
            {
                "name": task_name,
                "tags": ["lab"],
                "dependencies": [{"section": "Record/Edit/Upload", "name": task_name}],
            }
        )
    else:
        tasks["Record"]["tasks"].append(
            {
                "name": task_name,
                "tags": ["lab"],
                "dependencies": [{"section": "Preparation", "name": task_name}],
            }
        )
        tasks["Edit/Upload"]["tasks"].append(
            {
                "name": task_name,
                "tags": ["lab"],
                "dependencies": [{"section": "Record", "name": task_name}],
            }
        )
        tasks["Tech Writing"]["tasks"].append(
            {
                "name": f"Lab Guide: {item['name']}",
                "tags": ["lab"],
                "dependencies": [{"section": "Edit/Upload", "name": task_name}],
                "assigned_team": "TW",
            }
        )
        tasks["Tech Writing"]["tasks"].append(
            {
                "name": f"Lab Diagram: {item['name']}",
                "tags": ["lab"],
                "dependencies": [{"section": "Preparation", "name": task_name}],
                "assigned_team": "TW",
            }
        )
        tasks["Peer Review"]["tasks"].append(
            {
                "name": task_name,
                "tags": ["lab"],
                "dependencies": [{"section": "Edit/Upload", "name": task_name}],
            }
        )

    return tasks


def build_exam_tasks(item, with_video_editing=False):
    task_name = f"Exam - {item['name']}"

    tasks = __tasks_dictionary(with_video_editing)

    tasks["Preparation"]["tasks"].append({"name": task_name, "tags": ["quiz/exam"]})
    tasks["Tech Writing"]["tasks"].append(
        {
            "name": "Exam Question Pools",
            "tags": ["quiz/exam"],
            "dependencies": [{"section": "Preparation", "name": task_name}],
            "assigned_team": "TW",
        }
    )

    return tasks


def build_section_completion_tasks(section_name, with_video_editing):
    tasks = __tasks_dictionary(with_video_editing)

    tasks["Preparation"]["tasks"].append(
        {"name": f"Section Outlined: {section_name}", "is_milestone": True,}
    )
    if not with_video_editing:
        tasks["Tech Writing"]["tasks"].append(
            {
                "name": f"Section Review: {section_name}",
                "dependencies": [
                    {
                        "section": "Record/Edit/Upload",
                        "name": f"Section Complete: {section_name}",
                    }
                ],
                "assigned_team": "TW",
            }
        )
        tasks["Record/Edit/Upload"]["tasks"].append(
            {"name": f"Section Complete: {section_name}", "is_milestone": True,}
        )
    else:
        tasks["Tech Writing"]["tasks"].append(
            {
                "name": f"Section Review: {section_name}",
                "dependencies": [
                    {
                        "section": "Edit/Upload",
                        "name": f"Section Uploaded: {section_name}",
                    }
                ],
                "assigned_team": "TW",
            }
        )
        tasks["Record"]["tasks"].append(
            {"name": f"Section Complete: {section_name}", "is_milestone": True,}
        )
        tasks["Edit/Upload"]["tasks"].append(
            {"name": f"Section Uploaded: {section_name}", "is_milestone": True,}
        )

    return tasks


# Private Functions


def __tasks_dictionary(with_video_editing):
    tasks = {
        "Preparation": {"tasks": []},
        "Tech Writing": {"tasks": []},
    }

    if with_video_editing:
        tasks["Record"] = {"tasks": []}
        tasks["Edit/Upload"] = {"tasks": []}
    else:
        tasks["Record/Edit/Upload"] = {"tasks": []}

    tasks["Peer Review"] = {"tasks": []}
    tasks["Publication"] = {"tasks": []}

    return tasks


def __add_section(sections, section_name):
    sections[section_name] = {"tasks": []}
    return sections


def __add_tasks_to_sections(sections, tasks):
    for section_name, section in tasks.items():
        sections[section_name]["tasks"] += section["tasks"]


def __add_final_tasks(sections, previous_section_name, with_video_editing):
    tasks = build_section_completion_tasks(previous_section_name, with_video_editing)
    __add_tasks_to_sections(sections, tasks)

    sections["Preparation"]["tasks"].append(
        {"name": "Flash Cards", "tags": ["flashcards"],}
    )

    sections["Tech Writing"]["tasks"].append(
        {
            "name": "Flash Cards",
            "tags": ["flashcards"],
            "dependencies": [{"section": "Preparation", "name": "Flash Cards",}],
            "assigned_team": "TW",
        }
    )

    sections["Preparation"]["tasks"].append(
        {"name": "Study Guide", "tags": ["study guide"],}
    )

    sections["Tech Writing"]["tasks"].append(
        {
            "name": "Study Guide",
            "tags": ["study guide"],
            "dependencies": [{"section": "Preparation", "name": "Study Guide",}],
            "assigned_team": "TW",
        }
    )

    sections["Preparation"]["tasks"].append(
        {"name": "All Prep-work Complete", "is_milestone": True}
    )

    sections["Tech Writing"]["tasks"].append(
        {"name": "TW Complete", "is_milestone": True}
    )

    if not with_video_editing:
        sections["Record/Edit/Upload"]["tasks"].append(
            {"name": "Author Complete", "is_milestone": True}
        )
    else:
        sections["Record"]["tasks"].append(
            {"name": "Author Complete", "is_milestone": True}
        )
        sections["Edit/Upload"]["tasks"].append(
            {"name": "Video Editing Complete", "is_milestone": True}
        )

    sections["Peer Review"]["tasks"].append(
        {"name": "Peer Review Complete", "is_milestone": True}
    )

    sections["Publication"]["tasks"].append({"name": "All TW review complete"})

    sections["Publication"]["tasks"].append(
        {
            "name": "Pre-Publication Checklist",
            "subtasks": [
                "Flashcards",
                "Exams",
                "Study guides",
                "Labs and lab guides",
                "Video, lab, exam descriptions",
                "All TW, QDA, and Design tickets have been sent to the teams AND are completeCourse Description",
                "Currently TAs are using accounts on Google, Azure and AWS, and sometimes they forget to clean up the services when they finish the course which is a waste from a billing perspective",
                "Share course information for transcription.",
                "LucidChart is in the team folders",
                "All screenflow files are in dropbox",
                "Course Banner Image is Present",
                "Videos Unhidden (TAs should do that on posting, but ‘Preview Course’ to be sure)",
                "Course has a runtime (if not, request the timer script be run (VP of Content))",
                "Interactive Diagram URL added to CloudCraft (description and new URL field)",
                "Interactive Diagram Download Posted (if used)",
                "All Labs Published (If Early Access, incomplete labs must be removed from the syllabus as they cannot be hidden)",
                "Certification Prep (Checked for Cert Courses, Unchecked for all others)",
                "Course Features Selected (Practice Exam only needed for Certifications, Exercises should never be selected, All other features are available)",
                "Prerequisites are present (All courses should have something there, current Cloud Craft bug causes them to disappear periodically)",
                "Primary 'Topic' Correct",
                "Correct Author Selected",
                "Appropriate Categories Selected (Multiple categories in most cases depending on subject matter)",
                "Course Description - Early Access Message (if released prior to 100% completion)",
                "Standard Sections (Introduction, Conclusion - Standard videos in each)",
                "Instructor Flash Card Deck Selected",
                "Promo Video Selected",
            ],
        }
    )

    sections["Publication"]["tasks"].append({"name": "Published", "is_milestone": True})


def generate_syllabus_from_prep_tasks(tasks):
    """
    Returns a CC syllabus dictionary from the tasks that exist in
    the "Preparation" section of an Asana course project.
    """
    syllabus = {"sections": []}
    starting_index = 0
    slices = []
    for index, task in enumerate(tasks):
        task_name = task["name"] if type(task) == dict else task
        if task_name.startswith("Section Outlined: "):
            section_name = task_name.split(": ", 1)[1]
            slices.append((section_name, starting_index, index))
            starting_index = index + 1

    for section_name, start, end in slices:
        section = {"name": section_name, "items": []}

        for task in tasks[start:end]:
            task_name = task["name"] if type(task) == dict else task
            syllabus_item = __syllabus_item_from_name(task_name, section_name)
            section["items"].append(syllabus_item)

        syllabus["sections"].append(section)

    return syllabus


def __syllabus_item_from_name(task_name, section_name):
    """
    Returns the syllabus item type and item name based on the asana task name and the syllabus section name.
    These task names are expected to be from the "Preparation" section of the Asana project.
    """
    if task_name.endswith(f" ({section_name})"):
        lesson_name = task_name.split(f" ({section_name})", 1)[0]
        return {"type": "lesson", "name": lesson_name}
    elif task_name.startswith("Lab - "):
        lab_name = task_name.split("Lab - ", 1)[1]
        return {"type": "lab", "name": lab_name}
    elif task_name.startswith("Exam - "):
        exam_name = task_name.split("Exam - ", 1)[1]
        return {"type": "exam", "name": exam_name}


def flatten_syllabus(syllabus):
    """
    Returns a list of strings for the syllabus in the format of (SECTION_NAME) [ITEM_TYPE] ITEM_NAME
    """
    flat = []

    for section in syllabus["sections"]:
        section_name = section["name"]
        for item in section["items"]:
            if type(item) == str:
                flat.append(f"({section_name}) [lesson] {item}")
            else:
                flat.append(f"({section_name}) [{item['type'].lower()}] {item['name']}")

    return flat


def reconcile_syllabi(syllabus1, syllabus2):
    """
    Returns a new syllabus item containing the instructions for how to modify syllabus1 to achieve syllabus2

    Potentially modification keys on items are `insert_after`, `insert_before`, `delete`, or `change_to`
    """
    diff_syllabus = {"sections": []}

    differ = difflib.Differ()

    flat_syllabus1 = flatten_syllabus(syllabus1)
    flat_syllabus2 = flatten_syllabus(syllabus2)

    changes = []

    diff = differ.compare(flat_syllabus1, flat_syllabus2)
    diff_list = list(diff)
    diff_length = len(diff_list)

    for index, line in enumerate(diff_list):
        change_code, item = line[0:2], line[2:]
        if change_code == "  ":
            pass
        else:
            previous_line = diff_list[index - 1] if index > 0 else ""
            n1 = diff_list[index + 1] if index + 1 < diff_length else ""
            n2 = diff_list[index + 2] if index + 2 < diff_length else ""
            changes.append((previous_line, line, n1, n2))

    filtered_changes = __filter_changes(changes)

    change_dictionaries = __dictionaries_from_change_tuples(filtered_changes)

    for section_name, group in groupby(change_dictionaries, lambda d: d["section"]):
        items = [item.pop("section") and item for item in group]
        diff_syllabus["sections"].append({"name": section_name, "items": items})

    return diff_syllabus


def __filter_changes(changes):
    """
    Remove change tuples if the combination doesn't make sense.
    """
    # Filter out changes that don't make sense:
    filtered_changes = []
    for change in changes:
        prev, action, n1, n2 = change
        if prev.startswith("  ") and n1.startswith("? "):
            # This is in the middle of a modification to a line.
            continue
        elif prev.startswith("+ ") and action.startswith("? "):
            # This is after a modification a line is extended
            continue
        elif action.startswith("- ") and n1.startswith("+ ") and n2.startswith("? "):
            # This is before an addition modification
            continue
        elif action.startswith("- ") and n1.startswith("? ") and n2.startswith("+ "):
            # This is before a change
            continue
        elif action.startswith("+ ") and prev.startswith("? ") and n1.startswith("? "):
            # This is after a line has characters modified, but is the same length
            continue
        elif action.startswith("+ ") and re.match(r"\? *-+", prev):
            # This is after a line has been shortened
            continue
        else:
            filtered_changes.append(change)

    return filtered_changes


def __dictionaries_from_change_tuples(changes):
    """
    Returns a list of dictionaries created from a change 4-tuples
    """
    dicts = []
    line_pattern = ". \\((?P<section>.*)\\) \\[(?P<item_type>.*)\\] (?P<name>.*)"

    for prev, action, n1, n2 in changes:
        change_dict = {}

        if (
            (prev and prev.startswith("- "))
            and action.startswith("+ ")
            and (n1 and n1.startswith("? "))
        ):
            # This is a change extending a line.
            origName = re.match(line_pattern, prev).group("name")
            section, item_type, name = re.match(line_pattern, action).groups()

            change_dict = {
                "section": section,
                "type": item_type,
                "name": origName,
                "change_to": name,
            }
        elif (
            (prev and prev.startswith("- "))
            and action.startswith("? ")
            and (n1 and n1.startswith("+ "))
        ):
            # This is a change shortening a line
            origName = re.match(line_pattern, prev).group("name")

            section, item_type, name = re.match(line_pattern, n1).groups()

            change_dict = {
                "section": section,
                "type": item_type,
                "name": origName,
                "change_to": name,
            }
        elif action.startswith("- "):
            # This is a removal
            section, item_type, name = re.match(line_pattern, action).groups()
            change_dict = {
                "section": section,
                "type": item_type,
                "name": name,
                "delete": True,
            }
        elif action.startswith("+ "):
            # This is an addition
            section, item_type, name = re.match(line_pattern, action).groups()
            change_dict = {
                "section": section,
                "type": item_type,
                "name": name,
            }

            # Add insert after if prev is an item and in the same section
            if prev.startswith(" ") or prev.startswith("+ "):
                prev_section, item_type, name = re.match(line_pattern, prev).groups()
                if prev_section == section:
                    change_dict["insert_after"] = {
                        "name": name,
                        "type": item_type,
                    }

            elif n1.startswith(" "):
                n1_section, item_type, name = re.match(line_pattern, n1).groups()
                if n1_section == section:
                    change_dict["insert_before"] = {
                        "name": name,
                        "type": item_type,
                    }
            elif n2.startswith(" "):
                n2_section, item_type, name = re.match(line_pattern, n2).groups()
                if n2_section == section:
                    change_dict["insert_before"] = {
                        "name": name,
                        "type": item_type,
                    }

        dicts.append(change_dict)

    return dicts
