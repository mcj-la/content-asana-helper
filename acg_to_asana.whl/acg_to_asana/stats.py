class Stats:
    def __init__(self):
        self.videos = 0
        self.labs = 0
        self.exams = 0

    def add_video(self):
        self.videos += 1

    def add_lab(self):
        self.labs += 1

    def add_exam(self):
        self.exams += 1


def extract_item_counts(syllabus):
    """
    Returns an items with the count of videos, labs, and exams
    """
    stats = Stats()

    for section in syllabus["sections"]:
        for item in section["items"]:
            if type(item) == str:
                stats.add_video()
            elif item["type"].lower() == "lab":
                stats.add_lab()
            elif item["type"].lower() == "exam":
                stats.add_exam()

    return stats
