import pickle
import os
import os.path
import pygsheets
import pathlib
import time
import google
import sys
from functools import wraps

from acg_to_asana.tasks import parse_syllabus_file

from googleapiclient.errors import HttpError
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

TEMPLATE_SHEET_ID = os.getenv(
    "TEMPLATE_SHEET_ID", "10qG1559yBPRq9lxN5tPJn1qjRJtEtT38_EkYdGwTrrU"
)

MAIN_SHEET = "Lessons and Labs"
SECTION_TEMPLATE_PAGE_NAME = "section"
LESSON_TEMPLATE_PAGE_NAME = "lesson"


SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]

__CREDS_DIR = pathlib.Path(__file__).parent.absolute().joinpath("google_api")

def authenticate():
    creds = None

    token_file_name = os.path.expanduser("~/.standards_review/token.pickle")

    if os.path.exists(token_file_name):
        with open(token_file_name, "rb") as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except google.auth.exceptions.RefreshError:
                os.remove(token_file_name)
                print(
                    "Error: token refresh error and token automatically removed. Please run this command again to reauthenticate."
                )
                sys.exit(1)
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                __CREDS_DIR.joinpath("credentials.json"), SCOPES
            )
            creds = flow.run_local_server(port=0)

        try:
            base_dir = os.path.split(token_file_name)[0]
            os.makedirs(base_dir)
        except FileExistsError:
            pass

        with open(token_file_name, "wb") as token:
            pickle.dump(creds, token)

    return creds

def retry(func, exception=HttpError, error_code=429, delay=120):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except exception as e:
            if int(e.resp.status) == error_code:
                print(f"Hit API quota, waiting {delay} seconds to continue")
                time.sleep(delay)
                return func(*args, **kwargs)
            else:
                raise e

    return wrapper

@retry
def copy_template_spreadsheet(
    template_sheet_id, destionation_directory_id, name, service
):
    file_metadata = {"name": name, "parents": [destionation_directory_id]}

    response = (
        service.files()
        .copy(
            fileId=template_sheet_id,
            body=file_metadata,
        )
        .execute()
    )

    return response.get("id")

@retry
def add_item(
    item_type,
    item_name,
    worksheet,
    row_num,
    rows,
    src_worksheet,
    service,
    spreadsheet_id,
    index,
):
    if item_type == "section":
        cell_value = item_name
    else:
        cell_value = f"L{index} - {item_name}" if item_type == "lesson" else f"LAB{index} - {item_name}"

    body = {
        "requests": [
            {
                "copyPaste": {
                    "source": {
                        "sheetId": src_worksheet.id,
                        "startRowIndex": 0,
                        "endRowIndex": src_worksheet.rows,
                        "startColumnIndex": 0,
                        "endColumnIndex": src_worksheet.cols,
                    },
                    "destination": {
                        "sheetId": worksheet.id,
                        "startRowIndex": row_num - 1,
                        "endRowIndex": row_num + rows - 1,
                        "startColumnIndex": 0,
                        "endColumnIndex": src_worksheet.cols,
                    },
                    "pasteType": "PASTE_NORMAL",
                    "pasteOrientation": "NORMAL",
                },
            },
        ]
    }

    service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet_id, body=body
    ).execute()

    worksheet.update_value((row_num, 1), cell_value)

def main(destination_directory_id=None, spreadsheet_name=None, syllabus_file=None, template_id=None, breakout=False):
    if template_id == None:
        template_id = TEMPLATE_SHEET_ID
    
    creds = authenticate()
    client = pygsheets.authorize(custom_credentials=creds)

    sheets = build("sheets", "v4", credentials=creds)
    drive = build("drive", "v3", credentials=creds)

    syllabus = parse_syllabus_file(syllabus_file)
    course_name = syllabus.get("course_name", "<COURSE NAME HERE>")

    print("Copying Template Spreadsheet")
    new_sheet_id = copy_template_spreadsheet(
        template_id, destination_directory_id, spreadsheet_name, service=drive
    )

     # Open newly copied spreadsheet
    new_sheet = client.open_by_key(new_sheet_id)

    # Template worksheets
    
    main_template = new_sheet.worksheet_by_title(MAIN_SHEET)
    section_template = new_sheet.worksheet_by_title(SECTION_TEMPLATE_PAGE_NAME)
    lesson_template = new_sheet.worksheet_by_title(LESSON_TEMPLATE_PAGE_NAME)

    section_sheet_index = 1
    section_number = 1

    # Reset the lesson starting row per section
    starting_main_block_size = main_template.rows

    main_block_size = main_template.rows
    section_block_size = section_template.rows
    lesson_block_size = lesson_template.rows

    #print(f"starting block size: {str(main_block_size)}")

     # The rest goes here

    # Section Go here
    for section in syllabus.get("sections", []):
        session_name = f"S{str(section_number)} {section.get('name')}"

        print(f"{str(session_name)}") 

        main_template.add_rows(section_block_size)

        add_item(
            'section',
            session_name,
            row_num=starting_main_block_size,
            rows=section_block_size,
            worksheet=main_template,
            src_worksheet=section_template,
            service=sheets,
            spreadsheet_id=new_sheet.id,
            index=section_number,
        )

        section_sheet_index += 1
        section_number += 1

        # Reset the lesson starting row per section
        starting_main_block_size = main_template.rows

        #print(f"Row: {str(main_template.rows)}")
        #print(f"Next block size: {str(starting_main_block_size)}")

        lesson_index = 1
        lab_index = 1

        for item in section.get("items"):
            if item.get("type") not in ["lab", "lesson"]:
                continue
            
            main_template.add_rows(lesson_block_size)

            index = lesson_index if item.get("type") == "lesson" else lab_index

            # Lessons Go here
            add_item(
                item.get("type"),
                item.get("name"),
                row_num=starting_main_block_size,
                rows=lesson_block_size,
                worksheet=main_template,
                src_worksheet=lesson_template,
                service=sheets,
                spreadsheet_id=new_sheet.id,
                index=index,
            )

            if item.get("type") == "lesson":
                lesson_index += 1
            else:
                lab_index += 1

            # Reset the lesson starting row per section
            starting_main_block_size = main_template.rows
       
    #

    # Get new sheet url
    drive_url = f"https://docs.google.com/spreadsheets/d/{new_sheet.id}/edit"

    # Remove lesson template sheet
    new_sheet.del_worksheet(lesson_template)
    new_sheet.del_worksheet(section_template)

    print(f"Document URL: {drive_url}")

if __name__ == "__main__":
    import sys

    main(
        destination_directory_id=sys.argv[1],
        spreadsheet_name=sys.argv[2],
        syllabus_file="restful-s",
        template_id=sys.argv[4]
    )