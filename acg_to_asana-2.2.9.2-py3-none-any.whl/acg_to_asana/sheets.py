import pickle
import os
import os.path
import pygsheets
import pathlib
import time
import google
import sys
from functools import wraps

from acg_to_asana.tasks import parse_syllabus_file

from googleapiclient.errors import HttpError
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

TEMPLATE_SHEET_ID = os.getenv(
    "TEMPLATE_SHEET_ID", "10qG1559yBPRq9lxN5tPJn1qjRJtEtT38_EkYdGwTrrU"
)
SECTION_TEMPLATE_PAGE_NAME = "Section Name"
SLIDE_TEMPLATE_PAGE_NAME = "slides"
LESSON_TEMPLATE_PAGE_NAME = "lesson"
SLIDE_LESSON_TEMPLATE_PAGE_NAME = "slides-lessons"


SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]

__CREDS_DIR = pathlib.Path(__file__).parent.absolute().joinpath("google_api")


def authenticate():
    creds = None

    token_file_name = os.path.expanduser("~/.standards_review/token.pickle")

    if os.path.exists(token_file_name):
        with open(token_file_name, "rb") as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except google.auth.exceptions.RefreshError:
                os.remove(token_file_name)
                print(
                    "Error: token refresh error and token automatically removed. Please run this command again to reauthenticate."
                )
                sys.exit(1)
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                __CREDS_DIR.joinpath("credentials.json"), SCOPES
            )
            creds = flow.run_local_server(port=0)

        try:
            base_dir = os.path.split(token_file_name)[0]
            os.makedirs(base_dir)
        except FileExistsError:
            pass

        with open(token_file_name, "wb") as token:
            pickle.dump(creds, token)

    return creds


def retry(func, exception=HttpError, error_code=429, delay=120):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except exception as e:
            if int(e.resp.status) == error_code:
                print(f"Hit API quota, waiting {delay} seconds to continue")
                time.sleep(delay)
                return func(*args, **kwargs)
            else:
                raise e

    return wrapper


@retry
def create_section(sheet_name, course_name, spreadsheet, index, src_worksheet, service):

    try:
        section = spreadsheet.add_worksheet(
            sheet_name, index=index, src_worksheet=src_worksheet
        )
    except:
        section = spreadsheet.worksheet_by_title(sheet_name)

    body = {
        "requests": {
            "updateSheetProperties": {
                "properties": {
                    "sheetId": section.id,
                    "index": index,
                },
                "fields": "index",
            },
        }
    }

    service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet.id, body=body
    ).execute()

    update_section_title(service, spreadsheet, sheet_name, course_name)

    return section


@retry
def update_section_title(service, spreadsheet, sheet_name, course_name):
    service.spreadsheets().values().update(
        spreadsheetId=spreadsheet.id,
        range=f"{sheet_name}!B2",
        valueInputOption="USER_ENTERED",
        body={"values": [[f"{sheet_name} - {course_name}"]]},
    ).execute()


@retry
def add_item(
    item_type,
    item_name,
    worksheet,
    row_num,
    rows,
    src_worksheet,
    service,
    spreadsheet_id,
    index,
):
    cell_value = f"L{index} - {item_name}" if item_type == "lesson" else f"LAB{index} - {item_name}"

    body = {
        "requests": [
            {
                "copyPaste": {
                    "source": {
                        "sheetId": src_worksheet.id,
                        "startRowIndex": 0,
                        "endRowIndex": src_worksheet.rows,
                        "startColumnIndex": 0,
                        "endColumnIndex": src_worksheet.cols,
                    },
                    "destination": {
                        "sheetId": worksheet.id,
                        "startRowIndex": row_num - 1,
                        "endRowIndex": row_num + rows - 1,
                        "startColumnIndex": 0,
                        "endColumnIndex": src_worksheet.cols,
                    },
                    "pasteType": "PASTE_NORMAL",
                    "pasteOrientation": "NORMAL",
                },
            },
        ]
    }

    service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet_id, body=body
    ).execute()

    worksheet.update_value((row_num, 1), cell_value)


@retry
def copy_template_spreadsheet(
    template_sheet_id, destionation_directory_id, name, service
):
    file_metadata = {"name": name, "parents": [destionation_directory_id]}

    response = (
        service.files()
        .copy(
            fileId=template_sheet_id,
            body=file_metadata,
        )
        .execute()
    )

    return response.get("id")


@retry
def refresh_reporting(spreadsheet, service):
    service.spreadsheets().values().update(
        spreadsheetId=spreadsheet.id,
        range=f"Reporting!C12",
        valueInputOption="USER_ENTERED",
        body={"values": [['=SheetNamesAlt("Cover!Y11")']]},
    ).execute()


def main(destination_directory_id=None, spreadsheet_name=None, syllabus_file=None, template_id=None, breakout=False):

    print(f"breakout flag {str(breakout)}")

    if template_id == None:
        template_id = TEMPLATE_SHEET_ID
    
    creds = authenticate()
    client = pygsheets.authorize(custom_credentials=creds)

    sheets = build("sheets", "v4", credentials=creds)
    drive = build("drive", "v3", credentials=creds)

    syllabus = parse_syllabus_file(syllabus_file)
    course_name = syllabus.get("course_name", "<COURSE NAME HERE>")

    print("Copying Template Spreadsheet")
    new_sheet_id = copy_template_spreadsheet(
        template_id, destination_directory_id, spreadsheet_name, service=drive
    )

    # Open newly copied spreadsheet
    new_sheet = client.open_by_key(new_sheet_id)

    # Template worksheets
    section_template = new_sheet.worksheet_by_title(SECTION_TEMPLATE_PAGE_NAME)
    slide_template = new_sheet.worksheet_by_title(SLIDE_TEMPLATE_PAGE_NAME)
    lesson_template = new_sheet.worksheet_by_title(LESSON_TEMPLATE_PAGE_NAME)
    slide_lesson_template = new_sheet.worksheet_by_title(SLIDE_LESSON_TEMPLATE_PAGE_NAME)

    

    section_sheet_index = 1
    section_number = 1
    slide_block_size = slide_template.rows
    lesson_block_size = lesson_template.rows
    slide_lesson_block_size = slide_lesson_template.rows

    for section in syllabus.get("sections", []):
        session_name = f"S{str(section_number)} {section.get('name')}"

        if breakout:
            print(f"Creating Section: {session_name}")
            section_slides_sheet = create_section(
                f"{session_name} (slides)",
                course_name=course_name,
                index=section_sheet_index,
                src_worksheet=section_template,
                spreadsheet=new_sheet,
                service=sheets,
            )

            section_sheet_index += 1
            
            section_videos_sheet = create_section(
                f"{session_name} (videos)",
                course_name=course_name,
                index=section_sheet_index,
                src_worksheet=section_template,
                spreadsheet=new_sheet,
                service=sheets,
            )
        else:
            print(f"Creating Section: {section.get('name')}")
            section_sheet = create_section(
                session_name,
                course_name=course_name,
                index=section_sheet_index,
                src_worksheet=section_template,
                spreadsheet=new_sheet,
                service=sheets,
            )

        # Reset the lesson starting row per section
        slide_starting_row = section_template.rows
        lesson_starting_row = section_template.rows
        slide_lesson_starting_row = section_template.rows

        lesson_index = 1
        lab_index = 1
        for item in section.get("items"):
            if item.get("type") not in ["lab", "lesson"]:
                continue

            if breakout:
                section_slides_sheet.add_rows(slide_block_size)
                section_videos_sheet.add_rows(lesson_block_size)
            else:
                section_sheet.add_rows(slide_lesson_block_size)

            index = lesson_index if item.get("type") == "lesson" else lab_index

            print(f"Adding Item: {item.get('name')}")
            if breakout:
                add_item(
                    item.get("type"),
                    item.get("name"),
                    row_num=slide_starting_row,
                    rows=slide_starting_row,
                    worksheet=section_slides_sheet,
                    src_worksheet=slide_template,
                    service=sheets,
                    spreadsheet_id=new_sheet.id,
                    index=index,
                )

                add_item(
                    item.get("type"),
                    item.get("name"),
                    row_num=lesson_starting_row,
                    rows=lesson_block_size,
                    worksheet=section_videos_sheet,
                    src_worksheet=lesson_template,
                    service=sheets,
                    spreadsheet_id=new_sheet.id,
                    index=index,
                )
            else:
                add_item(
                    item.get("type"),
                    item.get("name"),
                    row_num=slide_lesson_starting_row,
                    rows=slide_lesson_starting_row,
                    worksheet=section_sheet,
                    src_worksheet=slide_lesson_template,
                    service=sheets,
                    spreadsheet_id=new_sheet.id,
                    index=index,
                )

            if item.get("type") == "lesson":
                lesson_index += 1
            else:
                lab_index += 1

            slide_starting_row += slide_block_size
            lesson_starting_row += lesson_block_size
            slide_lesson_starting_row += slide_lesson_block_size

        section_sheet_index += 1
        section_number += 1

    drive_url = f"https://docs.google.com/spreadsheets/d/{new_sheet.id}/edit"

    # Renaming Content Title
    print("Adjusting Cover Sheet Content")
    cover_sheet = new_sheet.worksheet_by_title("Cover")

    cover_sheet.update_value("E11", course_name)
    cover_sheet.update_value("E15", syllabus.get("course_id", ""))
    cover_sheet.update_value("E20", drive_url)
    cover_sheet.update_value("E22", drive_url)
    cover_sheet.update_value("E24", syllabus.get("url", ""))

    # Remove lesson template sheet
    new_sheet.del_worksheet(slide_template)
    new_sheet.del_worksheet(lesson_template)
    new_sheet.del_worksheet(slide_lesson_template)
    new_sheet.del_worksheet(section_template)

    # Update Reporting sheet so it pulls in new worksheets
    refresh_reporting(new_sheet, service=sheets)

    print(f"Document URL: {drive_url}")


if __name__ == "__main__":
    import sys

    main(
        destination_directory_id=sys.argv[1],
        spreadsheet_name=sys.argv[2],
        syllabus_file="restful-s",
        template_id=sys.argv[4]
    )
