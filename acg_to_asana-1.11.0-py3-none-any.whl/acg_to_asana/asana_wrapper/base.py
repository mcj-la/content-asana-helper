from datetime import datetime
from functools import reduce
from json import load, dump
import os


class TasksNotFoundError(Exception):
    def __init__(self, message, task_names=[]):
        super().__init__(message)
        self.task_names = task_names


class MissingTaskIdError(Exception):
    pass


class RemoteValues:
    def __init__(self):
        self.clear_values()

    def clear_values(self):
        self.tag_ids = {}
        self.remote_tasks = {}
        self.section_ids = {}
        self.remote_task_dependencies = {}
        self.update_task_actions = []
        self.subtask_actions = []

    def get_tag_id(self, tag_name):
        return self.tag_ids.get(tag_name)

    def set_tag_id(self, tag_name, tag_id):
        self.tag_ids[tag_name] = tag_id

    def get_task_id(self, section, task_name):
        key = self.__key(section, task_name)
        return self.remote_tasks.get(key)

    def set_task_id(self, section, task_name, task_id):
        key = self.__key(section, task_name)
        self.remote_tasks[key] = task_id

    def delete_task_id(self, task_id):
        remote_task_key = None

        for key, value in self.remote_tasks.items():
            if value == task_id:
                remote_task_key = key

        if remote_task_key:
            del self.remote_tasks[remote_task_key]

    def set_task_dependencies(self, task_id, deps):
        self.remote_task_dependencies[task_id] = deps

    def get_task_dependencies(self, task_id):
        return self.remote_task_dependencies.get(task_id)

    def get_section_id(self, section_name):
        return self.section_ids.get(section_name)

    def set_section_id(self, section_name, section_id):
        self.section_ids[section_name] = section_id

    def get_section_name(self, section_id):
        reversed_section_ids = dict(
            zip(self.section_ids.values(), self.section_ids.keys())
        )
        return reversed_section_ids.get(section_id)

    def get_tasks_for_section(self, section_name):
        tasks = map(lambda t: t.split("/", 1), self.remote_tasks.keys())
        return [name for section, name in tasks if section == section_name]

    def get_tasks_for_syllabus_section(self, section_name):
        items = []

        for task in self.remote_tasks.keys():
            _, task_name = task.split("/", 1)
            if (
                task_name.endswith(f": {section_name}")
                or f" ({section_name})" in task_name
            ):
                items.append(task)

        return items

    def get_task_ids_for_section(self, section_name):
        return [
            task_id
            for name, task_id in self.remote_tasks.items()
            if name.split("/", 1) == section_name
        ]

    def add_update_task_action(self, action):
        self.update_task_actions.append(action)

    def add_subtask_action(self, action):
        self.subtask_actions.append(action)

    def load_tag_cache(self, cache_file_name):
        cache_file_name = os.path.expanduser(cache_file_name)
        try:
            with open(cache_file_name, "r") as f:
                self.tag_ids = load(f)
                print(f"Tags loaded from cache at {cache_file_name}")
        except FileNotFoundError:
            print(f"Tag cache file not found at {cache_file_name}")
            self.tag_ids = {}

    def dump_tag_cache(self, cache_file_name):
        cache_file_name = os.path.expanduser(cache_file_name)
        try:
            base_dir = os.path.split(cache_file_name)[0]
            os.makedirs(base_dir)
        except FileExistsError:
            pass

        try:
            with open(cache_file_name, "w") as f:
                dump(self.tag_ids, f)
                print(f"Tags cached to {cache_file_name}.")
        except FileNotFoundError:
            print(
                f"Unable to write tag cache to {cache_file_name}. Ensure that you have write permissions."
            )

    def __key(self, section, task_name):
        return f"{section}/{task_name.strip()}"


CACHE = RemoteValues()

WORKSPACE_ID = "941019801419457"
ASSIGNED_TEAM_FIELD_ID = "1168108676943473"
ASSIGNED_TEAM_FIELD_OPTIONS = {
    "CDD": "1173781126309079",
    "Community": "1168108676943479",
    "Design": "1168108676943476",
    "ED": "1180065589856187",
    "Other": "1172991438701238",
    "PM": "1170536304353651",
    "Production": "1168108676943478",
    "Support": "1168108676943477",
    "TA": "1173573962399280",
    "TE": "1168108676943475",
    "TW": "1168108676943474",
    "VE": "1170536304353647",
}


def clear_cache():
    CACHE.clear_values()


def populate_tag_mapping(
    client, workspace_id, cache_file="~/.asana/tag_cache.json", break_cache=False
):
    """
    Add tag_id for each of the tag names in the workspace. Populates `TAG_ID_MAPPING` for use elsewhere.
    """
    CACHE.load_tag_cache(cache_file)

    if not CACHE.tag_ids or break_cache:
        for tag in client.tags.get_tags({"workspace": workspace_id}):
            CACHE.set_tag_id(tag["name"], tag["gid"])

        CACHE.dump_tag_cache(cache_file)


def populate_remote_tasks(client, project_id=None, populate_sections=False):
    """
    Get all remote tasks to populate Cache (assumes sections in Cache by default)
    """
    if populate_sections and project_id:
        populate_section_ids(client, project_id)

    for section_name, section_id in CACHE.section_ids.items():
        for task in client.tasks.find_by_section(section_id):
            CACHE.set_task_id(section_name, task["name"], task["gid"])


def populate_section_ids(client, project_id):
    """
    Get all sections from a project
    """
    for section in client.sections.find_by_project(project_id):
        CACHE.set_section_id(section["name"], section["gid"])


def get_missing_target_tasks(tasks):
    """
    Return a list of the insert_after and insert_before target task names that do not exist.
    """
    tasks = flatten_tasks(tasks)

    missing = []

    for task in tasks:
        before = task.get("insert_before")
        after = task.get("insert_after")
        if before and not CACHE.get_task_id(before["section"], before["name"]):
            missing.append(before)
        elif after and not CACHE.get_task_id(after["section"], after["name"]):
            missing.append(after)

    return missing


def delete_task(client, task_id):
    """
    Delete the given task_id
    """
    client.tasks.delete(task_id)
    CACHE.delete_task_id(task_id)


def create_missing_sections(client, project_id, section_names):
    """
    Create Required Sections in the Project if they don't exist. Also populate CACHE.section_ids
    """
    populate_section_ids(client, project_id)

    for section in section_names:
        if not CACHE.get_section_id(section):
            print(f"Creating Section: {section}")
            remote_section = client.sections.create_in_project(
                project_id, {"name": section}
            )
            CACHE.set_section_id(remote_section["name"], remote_section["gid"])


def create_task_in_section_by_id(client, project_id, section_id, task):
    """
    Create a task within the specified section
    """
    section_name = CACHE.get_section_name(section_id)

    data = {
        "name": task["name"],
        "projects": [project_id],
        "memberships": [{"project": project_id, "section": section_id,}],
        "tags": [CACHE.get_tag_id(t) for t in task.get("tags", [])],
    }

    remote_task = client.tasks.create(data)

    CACHE.set_task_id(section_name, remote_task["name"], remote_task["gid"])
    CACHE.set_task_dependencies(remote_task["gid"], task.get("dependencies"))

    update_task_action = None

    if task.get("assigned_team") and ASSIGNED_TEAM_FIELD_OPTIONS.get(
        task["assigned_team"]
    ):
        custom_fields = {
            f"{ASSIGNED_TEAM_FIELD_ID}": f"{ASSIGNED_TEAM_FIELD_OPTIONS[task['assigned_team']]}"
        }
        update_task_action = {
            "data": {"custom_fields": custom_fields},
            "method": "PUT",
            "relative_path": f"/tasks/{remote_task['gid']}",
        }

    if task.get("subtasks", []):
        for subtask in task.get("subtasks"):
            CACHE.add_subtask_action(
                {
                    "data": {"name": subtask},
                    "method": "POST",
                    "relative_path": f"/tasks/{remote_task['gid']}/subtasks",
                }
            )

    if task.get("is_milestone") and update_task_action:
        update_task_action["data"]["resource_subtype"] = "milestone"
    elif task.get("is_milestone"):
        update_task_action = {
            "data": {"resource_subtype": "milestone"},
            "method": "PUT",
            "relative_path": f"/tasks/{remote_task['gid']}",
        }

    if update_task_action:
        CACHE.add_update_task_action(update_task_action)

    if task.get("insert_after"):
        target = task.get("insert_after")
        target_id = CACHE.get_task_id(target["section"], target["name"])
        client.sections.add_task(
            section_id, {"task": remote_task["gid"], "insert_after": target_id},
        )
    elif task.get("insert_before"):
        target = task.get("insert_before")
        target_id = CACHE.get_task_id(target["section"], target["name"])
        client.sections.add_task(
            section_id, {"task": remote_task["gid"], "insert_before": target_id},
        )


def create_tasks_in_sections(client, project_id, section_name, section_tasks):
    """
    Creates tasks within the specified section_name
    """
    section_id = CACHE.get_section_id(section_name)
    for task in section_tasks:
        create_task_in_section_by_id(client, project_id, section_id, task)


def create_tasks_in_sections_by_id(client, project_id, section_id, section_tasks):
    """
    Creates tasks within the specified section_id
    """
    for task in section_tasks:
        create_task_in_section_by_id(client, project_id, section_id, task)


def set_all_task_dependencies(client):
    """
    Look up remote task id and set dependencies
    """
    for task_id in CACHE.remote_tasks.values():
        deps = CACHE.get_task_dependencies(task_id)
        if deps:
            set_task_dependencies(client, task_id, deps)


def set_task_dependencies(client, remote_task_id, dependencies):
    """
    Look up dependency remote task ids and set dependencies
    """
    dependency_ids = [CACHE.get_task_id(d["section"], d["name"]) for d in dependencies]
    client.tasks.add_dependencies(remote_task_id, {"dependencies": dependency_ids})


def remove_task_followers_for_tasks(client, project_id, section_tasks):
    """
    Remove the user as a follower from the designated tasks (skipping existing tasks)
    """
    follower_ids = get_project_followers(client, project_id)
    task_ids = []
    for section_name, section in section_tasks.items():
        section_task_ids = map(
            lambda task: CACHE.get_task_id(section_name, task["name"]),
            section["tasks"],
        )
        task_ids += section_task_ids

    for task_id in task_ids:
        client.tasks.remove_followers(task_id, {"followers": follower_ids})


def remove_task_followers(client, project_id, fetch_tasks=False):
    """
    Remove the user as a follower from each task created
    """
    follower_ids = get_project_followers(client, project_id)
    for task_id in CACHE.remote_tasks.values():
        client.tasks.remove_followers(task_id, {"followers": follower_ids})


def get_project_followers(client, project_id):
    """
    Return the follower id's for the project
    """
    project = client.projects.find_by_id(project_id)
    return [m["gid"] for m in project["members"]]


def update_project_details(
    client, project_id, videos, labs, exams, title="Initial Import"
):
    """
    Set the project description with information from the syllabus's stats
    """
    message = f"""Imported On: {datetime.now().strftime("%b %d, %Y")}

    Videos: {videos}
    Labs: {labs}
    Exams: {exams}
    """

    client.projects.update(
        project_id,
        {
            "notes": message,
            "current_status": {"color": "green", "title": title, "text": message,},
        },
    )


def flatten_tasks(tasks):
    if type(tasks) == dict:
        return reduce(lambda acc, section: acc + section["tasks"], tasks.values(), [])
    else:
        return tasks


def add_ids_to_tasks(section_tasks):
    """
    Add an `id` field to each task. If there are tasks without stored remote ids then collect them and raise an error.
    """
    missing_tasks = []

    for section_name, section in section_tasks.items():
        for task in section["tasks"]:
            remote_task_id = CACHE.get_task_id(section_name, task["name"])
            if remote_task_id:
                task["id"] = remote_task_id
            else:
                missing_tasks.append(f"{section_name}/{task['name']}")

    if any(missing_tasks):
        raise TasksNotFoundError("asana tasks not found", missing_tasks)


def update_task_name(client, task):
    """
    Update the name of the task in Asana. The `task` must have an `id` value.
    """
    task_id = task.get("id")
    if task_id:
        client.tasks.update(task_id, {"name": task["name"]})
    else:
        raise MissingTaskIdError("task must have an 'id' key")
