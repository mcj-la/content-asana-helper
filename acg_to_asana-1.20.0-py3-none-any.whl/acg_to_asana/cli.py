from functools import reduce
import click
import os
import sys
import subprocess
import requests
import tempfile
import acg_to_asana

from asana import Client

import acg_to_asana.asana_wrapper as wrapper
from acg_to_asana.asana_wrapper import TasksNotFoundError
from acg_to_asana.asana_wrapper import batch
from acg_to_asana.stats import extract_item_counts
from acg_to_asana.sheets import main as sheets_main
from acg_to_asana.tasks import (
    InvalidSyllabusError,
    build_section_completion_tasks,
    generate_section_tasks,
    generate_syllabus_from_prep_tasks,
    parse_syllabus_file,
    reconcile_syllabi,
    required_section_names,
    insertable_tasks_for_syllabus_item,
    prioritized_sections_for_deletion,
    merge_old_and_new_tasks,
    write_syllabus_file,
    separate_change_syllabus,
    ryan_generate_section_tasks,
    ryan_section_names,
)
from acg_to_asana.cc_wrapper import (
    BadAuthTokenError,
    CourseNotFoundError,
    fetch_formatted_syllabus,
)

REMOTE_UPDATE_URL = "https://childish-striped-aquarius.glitch.me/latest-release"


@click.group()
def asana_cli():
    pass


@click.command()
@click.option("--course-id", "-c", "course_id", required=True, help="the CC course id")
@click.option(
    "--yaml-file",
    "-f",
    "yaml_file",
    required=True,
    help="the YAML file to write the syllabus to.",
)
def export_cc_project(course_id, yaml_file):
    """Export a CloudCraft course syllabus as a YAML file.

    CC_AUTH_TOKEN environment variable must be set before using this command.
    """
    print(f"Fetching Syllabus for {course_id}")
    try:
        syllabus = fetch_formatted_syllabus(course_id)
    except (CourseNotFoundError, BadAuthTokenError) as err:
        print("Error:", err)
        sys.exit(1)
    except KeyError:
        print(
            "Error: please assign the CC_AUTH_TOKEN environment variable and try again."
        )
        sys.exit(1)

    print(f"Writing to {yaml_file}")
    write_syllabus_file(syllabus, yaml_file)


@click.command()
@click.option("--course-id", "-c", "course_id", required=True, help="the CC course id")
@click.option(
    "--output-dir",
    "-o",
    "output_dir",
    required=True,
    default=".",
    help="the directory to use as the root of the folder structure. Defaults to '.'",
)
@click.option(
    "--keynote-template",
    "-t",
    "keynote_template",
    required=False,
    help="an example Keynote file to copy & modify for each lesson. Will change '%TITLE%' to lesson title",
)
def cc_to_dropbox_structure(course_id, output_dir, keynote_template):
    """Generate Dropbox folder structure for the given course id. Each lesson will have a markdown file generated with the existing description placed in the 'Assets/Other' directory of the corresponding section.

    CC_AUTH_TOKEN environment variable must be set before using this command.
    """

    # If keynote_template is being used, check if keynote generation requirements are in place before doing anything.
    if keynote_template:
        try:
            from keynote_parser.command_line import replace_command
        except ImportError:
            print(
                """Error: Missing Optional Dependency

Run 'asana install_optional -f keynote' to install required dependencies."""
            )
            sys.exit(1)

    print(f"Fetching for {course_id}")
    try:
        syllabus = fetch_formatted_syllabus(course_id)
    except (CourseNotFoundError, BadAuthTokenError) as err:
        print("Error:", err)
        sys.exit(1)
    except KeyError:
        print(
            "Error: please assign the CC_AUTH_TOKEN environment variable and try again."
        )
        sys.exit(1)

    try:
        os.makedirs(output_dir)
    except:
        pass

    for section_index, section in enumerate(syllabus["sections"]):
        section_index += 1
        section_name = section["name"].replace("/", "-")
        description_directory = (
            f"{output_dir}/{section_index:02} - {section_name}/Lessons/Assets/Other"
        )

        slides_directory = (
            f"{output_dir}/{section_index:02} - {section_name}/Lessons/Assets/Slides"
        )

        default_directories = [
            f"{output_dir}/{section_index:02} - {section_name}/Hands-On Labs/Assets/Diagrams",
            f"{output_dir}/{section_index:02} - {section_name}/Hands-On Labs/Assets/Other",
            f"{output_dir}/{section_index:02} - {section_name}/Hands-On Labs/Assets/Slides",
            f"{output_dir}/{section_index:02} - {section_name}/Lessons/Assets/Diagrams",
            description_directory,
            slides_directory,
            f"{output_dir}/{section_index:02} - {section_name}/Hands-On Labs/Videos/Compressed Exports",
            f"{output_dir}/{section_index:02} - {section_name}/Hands-On Labs/Videos/ScreenFlow Exports",
            f"{output_dir}/{section_index:02} - {section_name}/Hands-On Labs/Videos/ScreenFlow Projects",
            f"{output_dir}/{section_index:02} - {section_name}/Lessons/Videos/Compressed Exports",
            f"{output_dir}/{section_index:02} - {section_name}/Lessons/Videos/ScreenFlow Exports",
            f"{output_dir}/{section_index:02} - {section_name}/Lessons/Videos/ScreenFlow Projects",
        ]

        print(f"Creating directory structure for {section_name}")
        for directory in default_directories:
            try:
                os.makedirs(directory)
            except:
                pass

        for item_index, item in enumerate(
            filter(lambda i: i["type"] == "lesson", section["items"])
        ):
            item_index += 1
            output_path = f"{description_directory}/S{section_index:02}_L{item_index:02}_{item['name'].replace('/', '-')}.md"
            with open(output_path, "w") as f:
                print(f"Writing to {output_path}")
                f.write(item["description"] or "")

            if keynote_template:
                output_path = f"{slides_directory}/S{section_index:02}_L{item_index:02}_{item['name'].replace('/', '-')}.key"

                print(f"Writing to {output_path}")
                replace_command(
                    keynote_template,
                    **{
                        "output": output_path,
                        "find": "%TITLE%",
                        "replace": item["name"],
                    },
                )


@click.command()
@click.option(
    "--directory-id",
    "-d",
    "directory_id",
    required=True,
    help="the Google Drive destination directory ID",
)
@click.option(
    "--name",
    "-n",
    "spreadsheet_name",
    required=True,
    help="the name of the new spreadsheet",
)
@click.option(
    "--yaml-file", "-f", "yaml_file", required=True, help="the syllabus YAML file.",
)
def standards_review(directory_id, spreadsheet_name, yaml_file):
    sheets_main(directory_id, spreadsheet_name, yaml_file)


@click.command()
@click.option(
    "--project", "-p", "project_id", required=True, help="the Asana project ID",
)
@click.option(
    "--yaml-file",
    "-f",
    "yaml_file",
    required=True,
    help="the YAML file containing the syllabus",
)
@click.option(
    "--video-editing",
    "--ve",
    is_flag=True,
    flag_value=True,
    help="indicate that this project has video editing, different resulting project structure.",
)
@click.option(
    "--for-ryan",
    "--fr",
    is_flag=True,
    flag_value=True,
    help="indicate that this project is for Ryan and requires a different structure.",
)
def import_project(project_id, yaml_file, video_editing, for_ryan):
    """Import data from a YAML file into a course project.
    """

    ASANA_TOKEN = os.getenv("ASANA_TOKEN")
    client = Client.access_token(ASANA_TOKEN)

    # Parse yaml_file of syllabus
    try:
        syllabus = parse_syllabus_file(yaml_file)
    except InvalidSyllabusError:
        print(
            f"Error: Unabled to parse syllabus file {yaml_file}. Ensure that it matches the expected format."
        )
        sys.exit(1)

    # Get Stats
    stats = extract_item_counts(syllabus)

    # Generate Tasks to Create (structure depends on --video-editing)
    if for_ryan:
        section_tasks = ryan_generate_section_tasks(syllabus)
        section_names = ryan_section_names(section_tasks)
    else:
        section_tasks = generate_section_tasks(syllabus, video_editing)
        section_names = required_section_names(video_editing)

    print("Creating Missing Sections")
    wrapper.create_missing_sections(client, project_id, section_names)

    # Populate Tags before creating Tasks
    print("Fetching Tag IDs")
    wrapper.populate_tag_mapping(client, wrapper.WORKSPACE_ID)

    # Create Tasks (also creates subtasks and sets milestones)
    for section_name in section_names:
        print(f"Creating Tasks for {section_name}")
        wrapper.create_tasks_in_sections(
            client, project_id, section_name, section_tasks[section_name]["tasks"]
        )

    # Wire Dependencies
    perform_batch_actions(client, project_id)

    # Update Project Status
    print("Updating Project Details")
    wrapper.update_project_details(
        client, project_id, stats.videos, stats.labs, stats.exams
    )


@click.command()
@click.option(
    "--project", "-p", "project_id", required=True, help="the Asana project ID",
)
@click.option(
    "--name", "-n", "item_name", required=True, help="the syllabus item name to add",
)
@click.option(
    "--section",
    "-s",
    "syllabus_section",
    required=True,
    help="the syllabus section containing the item",
)
@click.option(
    "--item-type",
    "-t",
    type=click.Choice(["lab", "lesson", "exam"], case_sensitive=False),
    default="lesson",
    help="the type of the syllabus item (default is 'lesson')",
)
@click.option(
    "--before",
    "-b",
    type=str,
    help="the name of the syllabus item to insert the new tasks before (in each section).",
)
@click.option(
    "--before-type",
    "-e",
    type=click.Choice(["lab", "lesson", "exam"], case_sensitive=False),
    default="lesson",
    help="the type of syllabus item to insert the new tasks before (defaults to 'lesson').",
)
@click.option(
    "--after",
    "-a",
    type=str,
    help="the name of the syllabus item to insert the new tasks after (in each section).",
)
@click.option(
    "--after-type",
    "-f",
    type=click.Choice(["lab", "lesson", "exam"], case_sensitive=False),
    default="lesson",
    help="the type of syllabus item to insert the new tasks after (defaults to 'lesson').",
)
@click.option(
    "--video-editing",
    "--ve",
    is_flag=True,
    flag_value=True,
    help="indicate that this project has video editing, different resulting project structure.",
)
def insert_command(
    project_id,
    item_name,
    syllabus_section,
    item_type,
    before,
    before_type,
    after,
    after_type,
    video_editing,
):
    """Create Asana tasks for given syllabus item and insert them in the proper location.
    """

    ASANA_TOKEN = os.getenv("ASANA_TOKEN")
    client = Client.access_token(ASANA_TOKEN)

    # Populate Remote Tasks and Sections
    print("Fetching Existing Sections and Tasks")
    wrapper.populate_remote_tasks(client, project_id, True)

    # Populate Tags before creating Tasks
    print("Fetching Tag IDs")
    wrapper.populate_tag_mapping(client, wrapper.WORKSPACE_ID)

    section_tasks = insert_tasks(
        client,
        project_id,
        item_name,
        item_type,
        syllabus_section,
        before=before,
        before_type=before_type,
        after=after,
        after_type=after_type,
        video_editing=video_editing,
    )

    print(
        f"DONE: Successfully inserted {len(wrapper.flatten_tasks(section_tasks))} tasks"
    )


def insert_asana_tasks_from_section_tasks(
    client,
    project_id,
    section_tasks,
    item_name=None,
    perform_printing=True,
    perform_batching=True,
):
    # Ensure that insert_after/insert_before tasks exist already.
    missing_tasks = wrapper.get_missing_target_tasks(section_tasks)

    if missing_tasks:
        print("Error: missing before/after target tasks in Asana")
        print("Ensure the following tasks are created:")
        for item in missing_tasks:
            print(f"\t * {item['section']} - {item['name']}")
        sys.exit(1)

    # Create Tasks (caches creation of subtasks and post creationg task updates)
    for section_name, section in section_tasks.items():
        if perform_printing and item_name:
            print(f"Creating Tasks for {item_name} in {section_name}")
        wrapper.create_tasks_in_sections(
            client, project_id, section_name, section["tasks"]
        )

    if perform_batching:
        perform_batch_actions(client, project_id)


def insert_tasks(
    client,
    project_id,
    item_name,
    item_type,
    syllabus_section,
    before=None,
    before_type=None,
    after=None,
    after_type=None,
    video_editing=False,
    perform_printing=True,
    perform_batching=True,
):
    # Generate Tasks for Insertions
    section_tasks = insertable_tasks_for_syllabus_item(
        item={"name": item_name, "type": item_type},
        syllabus_section=syllabus_section,
        with_video_editing=video_editing,
        insert_before=({"name": before, "type": before_type,} if before else None),
        insert_after=({"name": after, "type": after_type,} if after else None),
    )

    insert_asana_tasks_from_section_tasks(
        client,
        project_id,
        section_tasks,
        item_name=item_name,
        perform_printing=perform_printing,
        perform_batching=perform_batching,
    )

    return section_tasks


def perform_batch_actions(client, project_id):
    # Wire Dependencies
    print("Wiring up Dependencies")
    wrapper.batch.set_all_task_dependencies(client)

    print("Setting Milestones, Creating Subtasks, and Assigning Teams")
    wrapper.batch.process_all_cached_actions(client)

    # Remove Followers
    print("Removing Followers from Tasks")
    wrapper.batch.remove_task_followers(
        client, project_id, wrapper.CACHE.remote_tasks.values()
    )


@click.command()
@click.option(
    "--project", "-p", "project_id", required=True, help="the Asana project ID",
)
@click.option(
    "--name", "-n", "item_name", required=True, help="the syllabus item name",
)
@click.option(
    "--section",
    "-s",
    "syllabus_section",
    required=True,
    help="the syllabus section containing the item",
)
@click.option(
    "--item-type",
    "-t",
    type=click.Choice(["lab", "lesson", "exam"], case_sensitive=False),
    default="lesson",
    help="the type of the syllabus item (default is 'lesson')",
)
@click.option(
    "--video-editing",
    "--ve",
    is_flag=True,
    flag_value=True,
    help="indicate that this project has video editing, different resulting project structure.",
)
def delete_command(
    project_id, item_name, syllabus_section, item_type, video_editing,
):
    """Delete Asana tasks for given syllabus item.
    """

    ASANA_TOKEN = os.getenv("ASANA_TOKEN")
    client = Client.access_token(ASANA_TOKEN)

    # Populate Remote Tasks and Sections
    print("Fetching Existing Sections and Tasks")
    wrapper.populate_remote_tasks(client, project_id, True)

    # Generate Tasks for Deletion
    tasks_deleted = delete_tasks(
        client, item_name, item_type, syllabus_section, video_editing
    )

    print(f"DONE: Deleted {len(tasks_deleted)} tasks.")


def delete_tasks(client, item_name, item_type, syllabus_section, video_editing):
    section_tasks = insertable_tasks_for_syllabus_item(
        item={"name": item_name, "type": item_type},
        syllabus_section=syllabus_section,
        with_video_editing=video_editing,
    )

    # Delete Tasks (deleting tasks with assigned_teams first)
    tasks_deleted = []

    for section_name in prioritized_sections_for_deletion(section_tasks):
        for task in section_tasks[section_name]["tasks"]:
            task_id = wrapper.CACHE.get_task_id(section_name, task["name"])
            if task_id:
                wrapper.delete_task(client, task_id)
                tasks_deleted.append(task)

    return tasks_deleted


@click.command()
@click.option(
    "--project", "-p", "project_id", required=True, help="the Asana project ID"
)
@click.option(
    "--original",
    "-o",
    "item_name",
    required=True,
    help="the original syllabus item name",
)
@click.option(
    "--new", "-n", "new_item_name", required=True, help="the new syllabus item name"
)
@click.option(
    "--section",
    "-s",
    "syllabus_section",
    required=True,
    help="the syllabus section containing the item",
)
@click.option(
    "--item-type",
    "-t",
    type=click.Choice(["lab", "lesson", "exam"], case_sensitive=False),
    default="lesson",
    help="the type of the syllabus item (default is 'lesson')",
)
@click.option(
    "--video-editing",
    "--ve",
    is_flag=True,
    flag_value=True,
    help="indicate that this project has video editing, different resulting project structure.",
)
def change_command(
    project_id, item_name, new_item_name, syllabus_section, item_type, video_editing,
):
    """Changes Asana tasks for given syllabus item that has had a name change.
    """

    ASANA_TOKEN = os.getenv("ASANA_TOKEN")
    client = Client.access_token(ASANA_TOKEN)

    # Populate Remote Tasks and Sections
    print("Fetching Existing Sections and Tasks")
    wrapper.populate_remote_tasks(client, project_id, True)

    # Generate tasks for the original name
    print("Updating Tasks")
    tasks_changed = change_tasks(
        client, item_name, new_item_name, syllabus_section, item_type, video_editing
    )

    print(f"DONE: Changed {len(tasks_changed)} tasks.")


def change_tasks(
    client, item_name, new_item_name, syllabus_section, item_type, video_editing
):
    # Generate tasks for the original name
    original_section_tasks = insertable_tasks_for_syllabus_item(
        item={"name": item_name, "type": item_type},
        syllabus_section=syllabus_section,
        with_video_editing=video_editing,
    )

    # Generate tasks for the new name
    new_sectioned_tasks = insertable_tasks_for_syllabus_item(
        item={"name": new_item_name, "type": item_type},
        syllabus_section=syllabus_section,
        with_video_editing=video_editing,
    )

    # Ensure that original task names exist and add id's to original_section_tasks
    try:
        wrapper.add_ids_to_tasks(original_section_tasks)
    except TasksNotFoundError as err:
        print("Error: unable to locate tasks to change:")
        for task_name in err.task_names:
            print("\t*", task_name)
        sys.exit(1)

    # Zip original and new tasks, adding ids to associated `new_section_tasks`
    merge_old_and_new_tasks(original_section_tasks, new_sectioned_tasks)

    tasks_changed = []

    # Change tasks
    for section in new_sectioned_tasks.values():
        for task in section["tasks"]:
            wrapper.update_task_name(client, task)
            tasks_changed.append(task)

    return tasks_changed


@click.command()
@click.option(
    "--project", "-p", "project_id", required=True, help="the Asana project ID"
)
@click.option("--course-id", "-c", "course_id", required=True, help="the CC course id")
@click.option(
    "--yaml-file",
    "-f",
    "yaml_file",
    required=True,
    help="the YAML file to write the change syllabus to.",
)
@click.pass_context
def diff_syllabi(ctx, project_id, course_id, yaml_file):
    """Diff a CloudCraft course syllabus with an Asana Project.

    CC_AUTH_TOKEN environment variable must be set before using this command.
    """
    ASANA_TOKEN = os.getenv("ASANA_TOKEN")
    client = Client.access_token(ASANA_TOKEN)

    print("Fetching Existing Sections and Tasks")
    wrapper.populate_remote_tasks(client, project_id, True)

    print("Generating syllabus from Asana project")
    asana_syllabus = generate_syllabus_from_prep_tasks(
        wrapper.CACHE.get_tasks_for_section("Preparation")
    )

    print("Exporting syllabus from CloudCraft")
    with tempfile.TemporaryDirectory() as tmpdirname:
        syllabus_file_name = os.path.join(tmpdirname, "syllabus.json")
        ctx.invoke(export_cc_project, course_id=course_id, yaml_file=syllabus_file_name)

        cc_syllabus = parse_syllabus_file(syllabus_file_name)

    print("Generating change syllabus")
    change_syllabus = reconcile_syllabi(asana_syllabus, cc_syllabus)

    write_syllabus_file(change_syllabus, yaml_file)

    print(f"DONE: Change syllabus exported to {yaml_file}")


@click.command()
@click.option(
    "--project", "-p", "project_id", required=True, help="the Asana project ID",
)
@click.option(
    "--yaml-file",
    "-f",
    "yaml_file",
    required=True,
    help="the YAML file containing the syllabus changes",
)
@click.option(
    "--video-editing",
    "--ve",
    is_flag=True,
    flag_value=True,
    help="indicate that this project has video editing, different resulting project structure.",
)
def apply_change_syllabus(project_id, yaml_file, video_editing):
    """Make modifications to Asana project based on syllabus changes
    """

    ASANA_TOKEN = os.getenv("ASANA_TOKEN")
    client = Client.access_token(ASANA_TOKEN)

    print("Fetching Existing Sections and Tasks")
    wrapper.populate_remote_tasks(client, project_id, True)

    change_syllabus = parse_syllabus_file(yaml_file)

    # Separate Tasks into Changes, Insertions, and Deletions
    section_changes, changes, insertions, deletions = separate_change_syllabus(
        change_syllabus
    )

    if section_changes.get("added_sections") or section_changes.get("deleted_sections") or section_changes.get("changed_sections"):
        if section_changes["added_sections"]:
            # Populate Tags before creating Tasks
            print("Fetching Tag IDs")
            wrapper.populate_tag_mapping(client, wrapper.WORKSPACE_ID)

            # Perform Insertions
            with click.progressbar(
                section_changes["added_sections"], label="Adding Skeleton Tasks for New Sections"
            ) as bar:
                for section in bar:
                    section_tasks = build_section_completion_tasks(
                        section["name"],
                        with_video_editing=False,
                        insert_after_section=section.get("insert_after"),
                        insert_before_section=section.get("insert_before"),
                        cache=wrapper.CACHE,
                    )
                    insert_asana_tasks_from_section_tasks(
                        client,
                        project_id,
                        section_tasks,
                        perform_printing=False,
                        perform_batching=False,
                    )

        if section_changes["deleted_sections"]:
            # print("TODO: Deleting Skeleton Tasks for Deleted Sections")
            print("TODO: Exiting because this feature hasn't been implemented talk to Keith Thompson if you hit this")
            # print(section_changes["deleted_sections"])
            sys.exit(1)

        if section_changes["changed_sections"]:
            # Change All Tasks with `from` section value
            print("Performing Section Name Changes")
            for section_change in section_changes:
                batch.generate_change_syllabus_section_name_actions(
                    section_change["from"], section_change["to"]
                )

        perform_batch_actions(client, project_id)

        print(
            "Please rerun `asana diff ...` to generate a more accurate diff with correct section names. \nThen rerun `asana apply ...` with the new file."
        )
        sys.exit(0)

    # Perform Deletions
    tasks_deleted = []
    if deletions:
        length = sum(map(lambda s: len(s["items"]), deletions["sections"]))
        with click.progressbar(
            deletions["sections"], label="Deleting Tasks", length=length
        ) as bar:
            for section in bar:
                section_name = section["name"]
                for item in section["items"]:
                    tasks_deleted += delete_tasks(
                        client, item["name"], item["type"], section_name, video_editing
                    )

    # Make Changes
    tasks_changed = []
    if changes:
        length = sum(map(lambda s: len(s["items"]), changes["sections"]))
        with click.progressbar(
            changes["sections"], label="Modifying Tasks", length=length
        ) as bar:
            for section in bar:
                section_name = section["name"]
                for item in section["items"]:
                    tasks_changed += change_tasks(
                        client,
                        item["name"],
                        item["change_to"],
                        section_name,
                        item["type"],
                        video_editing,
                    )

    tasks_inserted = []
    if insertions:
        # Populate Tags before creating Tasks
        print("Fetching Tag IDs")
        wrapper.populate_tag_mapping(client, wrapper.WORKSPACE_ID)

        # Perform Insertions
        length = sum(map(lambda s: len(s["items"]), insertions["sections"]))
        with click.progressbar(
            insertions["sections"], label="Inserting new tasks", length=length
        ) as bar:
            for section in bar:
                section_name = section["name"]
                for item in section["items"]:
                    before = item.get("insert_before", {})
                    after = item.get("insert_after", {})

                    section_tasks = insert_tasks(
                        client,
                        project_id,
                        item["name"],
                        item["type"],
                        section_name,
                        before=before.get("name"),
                        before_type=before.get("type"),
                        after=after.get("name"),
                        after_type=after.get("type"),
                        video_editing=False,
                        perform_printing=False,
                        perform_batching=False,
                    )

                    tasks_inserted += wrapper.flatten_tasks(section_tasks)

    perform_batch_actions(client, project_id)

    print(
        f"DONE: {len(tasks_changed)} tasks updated, {len(tasks_inserted)} tasks created, and {len(tasks_deleted)} tasks deleted."
    )


@click.command()
def version_command():
    """Output the current version of the acg-to-asana package
    """
    print(f"acg-to-asana {acg_to_asana.__version__}")


@click.command()
def update_command():
    """Update to the newest version of acg-to-asana if not already on the latest version.
    """
    current_version = acg_to_asana.__version__

    resp = requests.get(REMOTE_UPDATE_URL)
    if resp.status_code == 200:
        latest = resp.json()

        if latest["version"] > current_version:
            print("Attempting to install latest version")

            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "--user", latest["url"]]
            )
        else:
            print("Already running the latest version")
    else:
        print("There was an error fetching the latest version info.")


@click.command()
@click.option(
    "--feature-name",
    "-f",
    "feature_name",
    required=True,
    help="the name of the optional feature to install dependencies for. Available: keynote",
)
def install_optional_command(feature_name):
    if feature_name.lower() == "keynote":
        print("Installing Homebrew Dependencies")
        subprocess.check_call(["brew", "install", "snappy", "libffi"])

        print(f"Installing Python dependencies for feature: {feature_name}")
        subprocess.check_call(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "--user",
                f"acg-to-asana[{feature_name.lower()}]",
            ]
        )


asana_cli.add_command(import_project, "import")
asana_cli.add_command(insert_command, "add")
asana_cli.add_command(delete_command, "del")
asana_cli.add_command(change_command, "chg")
asana_cli.add_command(diff_syllabi, "diff")
asana_cli.add_command(apply_change_syllabus, "apply")
asana_cli.add_command(update_command, "update")
asana_cli.add_command(version_command, "version")
asana_cli.add_command(install_optional_command, "install_optional")


def asana_main():
    asana_cli()


def cc_main():
    export_cc_project()


def cc_dropbox_main():
    cc_to_dropbox_structure()


def standards_review_main():
    standards_review()
